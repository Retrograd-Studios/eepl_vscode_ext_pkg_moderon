

SetPackageName(EEmbMessages)


SetSources("./")


