

SetPackageName(EEmbDeviceInfo)


SetSources("./")

