

SetPackageName(EEmbInteger)


SetSources("./")


