SetPackageName(EEmbRender)


SetSources("./")
