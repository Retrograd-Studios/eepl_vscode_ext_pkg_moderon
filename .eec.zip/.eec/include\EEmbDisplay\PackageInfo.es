

SetPackageName(EEmbDisplay)


SetSources("./")
